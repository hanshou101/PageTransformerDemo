/** Automatically generated file. DO NOT MODIFY */
package com.example.pagertransformer;

public final class BuildConfig {
    public final static boolean DEBUG = true;
}